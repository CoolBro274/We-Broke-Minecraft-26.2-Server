/*
 * HPPC
 *
 * Copyright (C) 2010-2024 Carrot Search s.c. and contributors
 * All rights reserved.
 *
 * Refer to the full license file "LICENSE.txt":
 * https://github.com/carrotsearch/hppc/blob/master/LICENSE.txt
 */
package net.lax1dude.eaglercraft.backend.server.api.collect;

/**
 * A predicate that applies to <code>Object</code>, <code>Object</code> pairs.
 */
public interface ObjectObjectPredicate<KType, VType> {
	public boolean apply(KType key, VType value);
}
